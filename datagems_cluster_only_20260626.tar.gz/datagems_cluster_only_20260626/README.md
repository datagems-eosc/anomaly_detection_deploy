# DataGEMS cluster access bundle

Created: 2026-06-26

This clean bundle contains only the files needed to access the DataGEMS Kubernetes cluster through the DataGEMS VPN. It intentionally does not include SSH keys, SSH config, personal server entries, server passwords, or redundant original archives.

## Files

- `vpn/OPENVPN_Server_yqi.ovpn`
  - DataGEMS OpenVPN profile.
  - VPN server: `185.179.104.45:1194/udp`
  - Adds route: `172.16.59.0/24`

- `kubernetes/datagems-upcite.kubeconfig`
  - DataGEMS Kubernetes config.
  - Source file was hidden as `.kubeconfig`; this copy is renamed so Finder can show it.
  - Context: `upcite`
  - Cluster API server: `https://172.16.59.4:6443`

- `kubernetes/ap-explanation-static-secret.yml`
  - Kubernetes manifest found in the same DataGEMS deployment folder.
  - Namespace: `upcite`

## How to connect

1. Import `vpn/OPENVPN_Server_yqi.ovpn` into an OpenVPN client.

2. Connect the VPN. The OpenVPN profile uses `auth-user-pass`, so you still need the DataGEMS VPN username/password. Those credentials are not stored in this bundle.

3. Test Kubernetes access:

```bash
kubectl --kubeconfig kubernetes/datagems-upcite.kubeconfig config get-contexts
kubectl --kubeconfig kubernetes/datagems-upcite.kubeconfig get ns
```

4. Use the `upcite` namespace:

```bash
kubectl --kubeconfig kubernetes/datagems-upcite.kubeconfig config set-context upcite --namespace=upcite
kubectl --kubeconfig kubernetes/datagems-upcite.kubeconfig get pods
```

## Security notes

- The kubeconfig contains Kubernetes client certificate/key data.
- The OpenVPN file contains VPN certificate material.
- This bundle does not contain SSH private keys or personal SSH server configs.
- Do not share it publicly.
